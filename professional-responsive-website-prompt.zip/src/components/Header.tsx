"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { LayoutGrid, Search, ShoppingBag, X } from "lucide-react";
import { useCart } from "./CartProvider";
import ProductImage from "./ProductImage";

export type NavCategory = { slug: string; name: string; count: number; lines: string[]; thumb: string };

function Logo({ className = "" }: { className?: string }) {
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img src="/brand/logo.webp" alt="Perfumes Imports All PY&BR" width={900} height={351} className={className} />
  );
}

function SearchForm({ id, onDone, autoFocus }: { id: string; onDone?: () => void; autoFocus?: boolean }) {
  const router = useRouter();
  return (
    <form action="/busca" role="search" className="relative w-full" onSubmit={() => onDone?.()}>
      <label htmlFor={id} className="sr-only">
        Buscar produtos
      </label>
      <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-mute" aria-hidden />
      <input
        id={id}
        name="q"
        type="search"
        required
        autoFocus={autoFocus}
        enterKeyHint="search"
        onKeyDown={(e) => {
          if (e.key !== "Enter") return;
          e.preventDefault();
          const q = e.currentTarget.value.trim();
          if (!q) return;
          router.push(`/busca?q=${encodeURIComponent(q)}`);
          onDone?.();
        }}
        placeholder="Buscar perfume, marca…"
        className="h-11 w-full rounded-full border border-sand-300 bg-white pl-11 pr-4 text-base text-ink placeholder:text-ink-mute/70 focus:border-flame-500 focus:outline-none focus:ring-4 focus:ring-flame-100 lg:text-[14px]"
      />
    </form>
  );
}

/** Botão que abre a tabela de categorias (fica ao lado da busca). */
function MenuButton({ open, onToggle, className }: { open: boolean; onToggle: () => void; className: string }) {
  return (
    <button
      type="button"
      data-menu-categorias
      onClick={onToggle}
      aria-expanded={open}
      aria-controls="menu-categorias"
      className={`h-10 shrink-0 items-center gap-2 rounded-full border px-3 text-[11px] min-[390px]:px-3.5 font-semibold uppercase tracking-[0.12em] transition active:scale-[0.97] lg:h-11 lg:px-4 lg:text-[11.5px] ${
        open
          ? "border-ink bg-ink text-cream"
          : "border-sand-300 bg-white text-ink hover:border-flame-500 hover:text-flame-700"
      } ${className}`}
    >
      {open ? (
        <X className="h-[17px] w-[17px]" strokeWidth={1.8} aria-hidden />
      ) : (
        <LayoutGrid className="h-[17px] w-[17px]" strokeWidth={1.6} aria-hidden />
      )}
      <span className="max-[349px]:sr-only">Categorias</span>
    </button>
  );
}

export default function Header({
  categories,
  announcement,
}: {
  categories: NavCategory[];
  announcement: string;
}) {
  const { count, ready, setOpen } = useCart();
  const pathname = usePathname();
  const isHome = pathname === "/";
  const [catsOpen, setCatsOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  // Na página inicial a logo fica no centro da tela; a logo do topo só aparece depois de rolar.
  const [bigLogoVisible, setBigLogoVisible] = useState(isHome);
  const headerRef = useRef<HTMLElement>(null);

  const closeCats = useCallback(() => setCatsOpen(false), []);
  const toggleCats = () => {
    setSearchOpen(false);
    setCatsOpen((v) => !v);
  };

  useEffect(() => {
    const big = isHome ? document.getElementById("logo-inicial") : null;
    if (!big || !("IntersectionObserver" in window)) {
      setBigLogoVisible(false);
      return;
    }
    setBigLogoVisible(true);
    const io = new IntersectionObserver(([entry]) => setBigLogoVisible(entry.isIntersecting), {
      rootMargin: `-${headerRef.current?.offsetHeight ?? 110}px 0px 0px 0px`,
    });
    io.observe(big);
    return () => io.disconnect();
  }, [isHome]);

  // Fecha a tabela e a busca ao trocar de página.
  useEffect(() => {
    setCatsOpen(false);
    setSearchOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!catsOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      setCatsOpen(false);
      const buttons = document.querySelectorAll<HTMLButtonElement>("[data-menu-categorias]");
      [...buttons].find((b) => b.offsetParent !== null)?.focus();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [catsOpen]);

  // A faixa de aviso aparece só nas páginas internas.
  const notice = isHome ? "" : announcement;
  const iconBtn =
    "relative grid h-11 w-11 shrink-0 place-items-center rounded-full text-ink transition hover:bg-sand-100 active:scale-95";

  // Células vazias para a tabela fechar certinho quando o número de categorias não completa a linha.
  const fillDesktop = (4 - (categories.length % 4)) % 4;
  const fillMobile = categories.length % 2;

  return (
    <>
      {notice ? (
        <p className="bg-flame-600 px-4 py-2 text-center text-[11px] font-medium uppercase leading-snug tracking-[0.16em] text-white sm:text-[11.5px]">
          {notice}
        </p>
      ) : null}

      <header ref={headerRef} className="sticky top-0 z-40 border-b border-sand-200 bg-cream/90 backdrop-blur-md">
        <div className="container-x flex h-16 items-center justify-between gap-2 lg:grid lg:h-[76px] lg:grid-cols-[1fr_auto_1fr] lg:gap-4">
          {/* Computador: categorias e busca à esquerda */}
          <div className="hidden items-center gap-3 lg:flex">
            <MenuButton open={catsOpen} onToggle={toggleCats} className="hidden lg:inline-flex" />
            <div className="w-full max-w-[240px]">
              <SearchForm id="busca-desktop" />
            </div>
          </div>

          <Link
            href="/"
            aria-label="Perfumes Imports, página inicial"
            aria-hidden={bigLogoVisible || undefined}
            tabIndex={bigLogoVisible ? -1 : undefined}
            className={`shrink-0 transition-opacity duration-300 lg:justify-self-center ${
              bigLogoVisible ? "pointer-events-none opacity-0" : "opacity-100"
            }`}
          >
            <Logo className="h-9 w-auto min-[390px]:h-10 lg:h-[54px]" />
          </Link>

          <div className="flex items-center justify-end gap-1">
            {/* Celular: categorias ao lado da lupa */}
            <MenuButton open={catsOpen} onToggle={toggleCats} className="mr-1 inline-flex lg:hidden" />
            <button
              type="button"
              className={`${iconBtn} lg:hidden`}
              onClick={() => {
                setCatsOpen(false);
                setSearchOpen((v) => !v);
              }}
              aria-label="Buscar"
              aria-expanded={searchOpen}
            >
              {searchOpen ? <X className="h-5 w-5" strokeWidth={1.6} /> : <Search className="h-5 w-5" strokeWidth={1.6} />}
            </button>
            <button type="button" className={`${iconBtn} -mr-2`} onClick={() => setOpen(true)} aria-label={`Abrir sacola (${ready ? count : 0} itens)`}>
              <ShoppingBag className="h-[22px] w-[22px]" strokeWidth={1.6} />
              {ready && count > 0 ? (
                <span className="absolute right-0.5 top-0.5 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-flame-600 px-1 text-[10px] font-semibold leading-none text-white">
                  {count}
                </span>
              ) : null}
            </button>
          </div>
        </div>

        {searchOpen ? (
          <div className="container-x animate-fade pb-3 lg:hidden">
            <SearchForm id="busca-mobile" autoFocus onDone={() => setSearchOpen(false)} />
          </div>
        ) : null}

        <nav aria-label="Categorias" className="hidden border-t border-sand-200/70 lg:block">
          <ul className="container-x flex flex-wrap items-center justify-center gap-x-8 gap-y-1 xl:gap-x-10">
            {categories.map((c) => {
              const active = pathname === `/categoria/${c.slug}`;
              return (
                <li key={c.slug}>
                  <Link
                    href={`/categoria/${c.slug}`}
                    aria-current={active ? "page" : undefined}
                    className={`relative block py-3 text-[12px] font-medium uppercase tracking-[0.2em] transition after:absolute after:inset-x-0 after:bottom-1.5 after:h-px after:origin-left after:bg-flame-600 after:transition-transform after:duration-300 hover:text-flame-700 hover:after:scale-x-100 ${
                      active ? "text-flame-700 after:scale-x-100" : "text-ink-soft after:scale-x-0"
                    }`}
                  >
                    {c.name}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Tabela de categorias */}
        {catsOpen ? (
          <div
            id="menu-categorias"
            className="absolute inset-x-0 top-full max-h-[calc(100dvh_-_7.5rem)] animate-fade overflow-y-auto overscroll-contain border-t border-sand-200 bg-cream shadow-soft"
          >
            <nav aria-label="Todas as categorias" className="container-x py-4 lg:py-7">
              <ul className="grid grid-cols-2 gap-px overflow-hidden rounded-[1.25rem] border border-sand-200 bg-sand-200 lg:grid-cols-4 lg:rounded-[1.5rem]">
                {categories.map((c) => {
                  const active = pathname === `/categoria/${c.slug}`;
                  return (
                    <li key={c.slug} className="bg-cream">
                      <Link
                        href={`/categoria/${c.slug}`}
                        onClick={closeCats}
                        aria-current={active ? "page" : undefined}
                        className="group flex items-center gap-3 p-3 transition hover:bg-sand-50 lg:gap-4 lg:p-5"
                      >
                        <span className="block h-[58px] w-[46px] shrink-0 overflow-hidden rounded-xl bg-sand-100 max-[349px]:hidden lg:h-[72px] lg:w-[58px] lg:rounded-2xl">
                          <ProductImage src={c.thumb} alt="" category={c.slug} compact />
                        </span>
                        <span className="min-w-0">
                          <span
                            className={`block font-display text-[1.02rem] leading-[1.15] transition group-hover:text-flame-700 lg:text-[1.3rem] ${
                              active ? "text-flame-700" : "text-ink"
                            }`}
                          >
                            {c.name}
                          </span>
                          <span className="mt-1 block whitespace-nowrap text-[10px] uppercase tracking-[0.1em] text-ink-mute lg:text-[11px] lg:tracking-[0.16em]">
                            {c.count} {c.count === 1 ? "produto" : "produtos"}
                          </span>
                        </span>
                      </Link>
                      {c.lines.length > 1 ? (
                        <ul className="hidden flex-wrap gap-x-4 gap-y-1 px-5 pb-5 lg:flex">
                          {c.lines.map((line) => (
                            <li key={line}>
                              <Link
                                href={`/categoria/${c.slug}?linha=${encodeURIComponent(line)}`}
                                onClick={closeCats}
                                className="text-[13px] text-ink-mute underline-offset-4 transition hover:text-flame-700 hover:underline"
                              >
                                {line}
                              </Link>
                            </li>
                          ))}
                        </ul>
                      ) : null}
                    </li>
                  );
                })}
                {Array.from({ length: fillDesktop }, (_, i) => (
                  <li key={`vazio-${i}`} aria-hidden className={`bg-cream ${i < fillMobile ? "" : "hidden lg:block"}`} />
                ))}
              </ul>
            </nav>
          </div>
        ) : null}
      </header>

      {/* Fundo escurecido enquanto a tabela está aberta */}
      {catsOpen ? <div aria-hidden onClick={closeCats} className="fixed inset-0 z-30 animate-fade bg-ink/35" /> : null}
    </>
  );
}
