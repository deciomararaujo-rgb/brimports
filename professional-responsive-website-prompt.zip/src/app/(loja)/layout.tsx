import type { ReactNode } from "react";
import CartDrawer from "@/components/CartDrawer";
import CartProvider from "@/components/CartProvider";
import Footer from "@/components/Footer";
import Header from "@/components/Header";
import { getActiveProducts, getCategories, getSettings } from "@/lib/store";

export const dynamic = "force-dynamic";

export default async function StoreLayout({ children }: { children: ReactNode }) {
  const [s, cats, all] = await Promise.all([getSettings(), getCategories(), getActiveProducts()]);

  // Dados da tabela de categorias do topo: quantidade, linhas e uma foto de cada categoria.
  const nav = cats.map((c) => {
    const items = all.filter((p) => p.categorySlug === c.slug);
    const lines: string[] = [];
    for (const p of [...items].sort((a, b) => a.sort - b.sort)) {
      if (p.subcategory && !lines.includes(p.subcategory)) lines.push(p.subcategory);
    }
    return {
      slug: c.slug,
      name: c.name,
      count: items.length,
      lines,
      thumb: items.find((p) => p.imageUrl)?.imageUrl ?? "",
    };
  });

  return (
    <CartProvider>
      <a
        href="#conteudo"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[70] focus:rounded-full focus:bg-ink focus:px-5 focus:py-3 focus:text-cream"
      >
        Pular para o conteúdo
      </a>
      <Header categories={nav} announcement={s.announcement} />
      <main id="conteudo">{children}</main>
      <Footer
        whatsapp={s.whatsappNumber}
        shippingCents={s.shippingCents}
        shippingDays={s.shippingDays}
        maxInstallments={s.maxInstallments}
        pickupEnabled={s.pickupEnabled}
      />
      <CartDrawer shippingCents={s.shippingCents} shippingDays={s.shippingDays} />
    </CartProvider>
  );
}
