import Link from "next/link";
import { CreditCard, MapPin, QrCode, Truck } from "lucide-react";
import { formatBRL, prettyWhats, waLink } from "@/lib/format";
import { WhatsAppIcon } from "./icons";

export default function Footer({
  whatsapp,
  shippingCents,
  shippingDays,
  maxInstallments,
  pickupEnabled,
}: {
  whatsapp: string;
  shippingCents: number;
  shippingDays: number;
  maxInstallments: number;
  pickupEnabled: boolean;
}) {
  const help = waLink(whatsapp, "Olá! Vim pelo site e gostaria de tirar uma dúvida.");
  const heading = "text-[11px] font-semibold uppercase tracking-[0.26em] text-ink";
  const link = "text-[15px] text-ink-soft transition hover:text-flame-700";

  return (
    <footer className="mt-24 border-t border-sand-200 bg-sand-100">
      <div className="container-x grid gap-10 py-12 sm:grid-cols-2 lg:grid-cols-3 lg:gap-12 lg:py-16">
        {/* O botão Tirar dúvidas fica só aqui, no final do site */}
        <div className="sm:col-span-2 lg:col-span-1">
          <a href={help} target="_blank" rel="noopener noreferrer" className="btn btn-whats w-full sm:w-auto">
            <WhatsAppIcon className="h-5 w-5" />
            Tirar dúvidas
          </a>
        </div>

        <div>
          <h2 className={heading}>Atendimento</h2>
          <ul className="mt-5 space-y-2.5">
            <li>
              <a href={help} target="_blank" rel="noopener noreferrer" className={link}>
                WhatsApp {prettyWhats(whatsapp)}
              </a>
            </li>
            <li>
              <Link href="/busca" className={link}>
                Buscar produtos
              </Link>
            </li>
            <li>
              <Link href="/checkout" className={link}>
                Finalizar compra
              </Link>
            </li>
            <li>
              <Link href="/admin" className={link}>
                Área da loja
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h2 className={heading}>Pagamento e entrega</h2>
          <ul className="mt-5 space-y-3.5 text-[15px] text-ink-soft">
            <li className="flex gap-3">
              <QrCode className="mt-0.5 h-5 w-5 shrink-0 text-flame-600" strokeWidth={1.5} />
              Pix com QR Code e copia e cola
            </li>
            <li className="flex gap-3">
              <CreditCard className="mt-0.5 h-5 w-5 shrink-0 text-flame-600" strokeWidth={1.5} />
              Cartão de crédito{maxInstallments > 1 ? ` em até ${maxInstallments}x` : ""}
            </li>
            <li className="flex gap-3">
              <Truck className="mt-0.5 h-5 w-5 shrink-0 text-flame-600" strokeWidth={1.5} />
              Motoboy por {formatBRL(shippingCents)}, em até {shippingDays} {shippingDays === 1 ? "dia útil" : "dias úteis"}
            </li>
            {pickupEnabled ? (
              <li className="flex gap-3">
                <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-flame-600" strokeWidth={1.5} />
                Retirada ou entrega local em Guarulhos
              </li>
            ) : null}
          </ul>
        </div>
      </div>

      <div className="border-t border-sand-200">
        <div className="container-x flex flex-col gap-2 py-6 pb-24 text-[13px] text-ink-mute sm:flex-row sm:items-center sm:justify-between sm:pb-6">
          <p>© {new Date().getFullYear()} Perfumes Imports All PY&BR. Todos os direitos reservados.</p>
          <p>Guarulhos · São Paulo</p>
        </div>
      </div>
    </footer>
  );
}
