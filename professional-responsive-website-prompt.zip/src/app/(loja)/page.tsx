import Link from "next/link";
import { ArrowRight } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import Reveal from "@/components/Reveal";
import { toCard } from "@/lib/cards";
import { responsive } from "@/lib/img";
import { getActiveProducts, getCategories, getSettings } from "@/lib/store";

export const dynamic = "force-dynamic";

// Quantos produtos cada vitrine mostra (no computador aparecem os 5 primeiros).
const PER_ROW = 10;

/** Folha em traço fino, como no fundo da identidade visual da loja. */
function Leaf({ className }: { className: string }) {
  return (
    <svg viewBox="0 0 400 400" fill="none" stroke="currentColor" strokeLinecap="round" aria-hidden className={className}>
      <path d="M30 370C30 190 190 30 370 30C370 210 210 370 30 370Z" strokeWidth="8" />
      <path
        d="M30 370L370 30M30 370L132 132M30 370L217 69M30 370L291 40M30 370L267 267M30 370L331 183M30 370L360 109"
        strokeWidth="3.5"
      />
    </svg>
  );
}

// Página inicial: logo, temas da loja e uma vitrine de produtos por categoria.
export default async function HomePage() {
  const [s, cats, all] = await Promise.all([getSettings(), getCategories(), getActiveProducts()]);
  const installments = { max: s.maxInstallments, free: s.interestFree };
  const themes = s.banners;
  // No celular os temas ficam em duas colunas; se a quantidade for ímpar, o primeiro ocupa a largura toda.
  const oddCount = themes.length % 2 === 1;

  // Os produtos marcados como destaque no painel aparecem primeiro em cada vitrine.
  const rows = cats
    .map((cat) => {
      const items = all.filter((p) => p.categorySlug === cat.slug);
      return { cat, total: items.length, items: items.slice(0, PER_ROW).map(toCard) };
    })
    .filter((row) => row.total > 0);

  return (
    <>
      <section className="relative overflow-hidden bg-[radial-gradient(85%_75%_at_50%_45%,#fffdf9_0%,#f8f1e6_55%,#f3e9da_100%)]">
        <Leaf className="pointer-events-none absolute -left-16 -top-20 w-[150px] rotate-[98deg] text-sand-300/55 sm:w-[220px] lg:-left-20 lg:-top-28 lg:w-[320px]" />
        <Leaf className="pointer-events-none absolute -bottom-24 -right-16 w-[160px] -rotate-[78deg] text-sand-300/55 sm:w-[230px] lg:-bottom-32 lg:-right-20 lg:w-[340px]" />
        <div className="container-x relative grid place-items-center py-9 sm:py-10 lg:py-12">
          <h1 id="logo-inicial" className="animate-[fade_1.2s_ease_both]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/brand/logo.webp"
              alt={`${s.storeName} All PY&BR`}
              width={900}
              height={351}
              fetchPriority="high"
              className="h-auto w-[min(50vw,220px)] lg:w-[280px]"
            />
          </h1>
        </div>
      </section>

      {themes.length ? (
        <section aria-label="Temas da loja" className="container-x pt-6 sm:pt-8 lg:pt-12">
          <ul className="flex flex-wrap justify-center gap-3 sm:gap-5 lg:gap-7">
            {themes.map((theme, i) => {
              const wide = oddCount && i === 0;
              const img = responsive(theme.image, wide ? 1080 : 828);
              return (
                <li
                  key={`${theme.image}-${i}`}
                  className={`${
                    wide ? "w-full" : "w-[calc((100%_-_0.75rem)_/_2)]"
                  } sm:w-[calc((100%_-_2.5rem)_/_3)] lg:w-[calc((100%_-_3.5rem)_/_3)]`}
                >
                  <Reveal delay={(i % 3) * 90} className="h-full">
                    <Link
                      href={theme.href}
                      aria-label={theme.label || "Ver produtos"}
                      className="group block aspect-[4/5] overflow-hidden rounded-[1.4rem] bg-sand-200 shadow-card transition-shadow duration-500 hover:shadow-soft sm:rounded-[1.6rem] lg:rounded-[2.25rem]"
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={img.src}
                        srcSet={img.srcSet}
                        sizes={
                          img.srcSet
                            ? wide
                              ? "(min-width: 1320px) 420px, (min-width: 640px) 33vw, 100vw"
                              : "(min-width: 1320px) 420px, (min-width: 640px) 33vw, 50vw"
                            : undefined
                        }
                        alt={theme.label}
                        loading={i < 3 ? "eager" : "lazy"}
                        decoding="async"
                        className="h-full w-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.04]"
                      />
                    </Link>
                  </Reveal>
                </li>
              );
            })}
          </ul>
        </section>
      ) : null}

      {/* Vitrines: produtos de cada categoria */}
      {rows.map(({ cat, items, total }) => (
        <section key={cat.slug} aria-labelledby={`vitrine-${cat.slug}`} className="container-x pt-12 lg:pt-20">
          <Reveal>
            <div className="mb-5 flex items-end justify-between gap-4 lg:mb-8">
              <h2 id={`vitrine-${cat.slug}`} className="display text-[clamp(1.7rem,3.4vw,2.5rem)]">
                {cat.name}
              </h2>
              <Link
                href={`/categoria/${cat.slug}`}
                aria-label={`Ver todos os produtos de ${cat.name}`}
                className="link-underline mb-1 inline-flex shrink-0 items-center gap-2 text-[11.5px] font-semibold uppercase tracking-[0.18em] text-ink"
              >
                Ver todos
                <ArrowRight className="h-4 w-4" aria-hidden />
              </Link>
            </div>

            <ul className="no-scrollbar -mx-5 flex snap-x snap-mandatory scroll-pl-5 gap-3.5 overflow-x-auto px-5 pb-2 sm:-mx-8 sm:scroll-pl-8 sm:gap-5 sm:px-8 lg:mx-0 lg:grid lg:grid-cols-5 lg:gap-x-6 lg:overflow-visible lg:px-0 lg:pb-0 lg:[&>li:nth-child(n+6)]:hidden">
              {items.map((p) => (
                <li key={p.id} className="w-[44%] shrink-0 snap-start sm:w-[30%] lg:w-auto">
                  <ProductCard product={p} installments={installments} />
                </li>
              ))}
              {total > items.length ? (
                <li className="w-[44%] shrink-0 snap-start sm:w-[30%] lg:hidden">
                  <Link
                    href={`/categoria/${cat.slug}`}
                    className="flex aspect-[4/5] flex-col items-center justify-center gap-3 rounded-[1.6rem] border border-sand-200 bg-sand-50 px-4 text-center transition hover:border-flame-400"
                  >
                    <span className="grid h-11 w-11 place-items-center rounded-full bg-white text-flame-600 shadow-card">
                      <ArrowRight className="h-5 w-5" aria-hidden />
                    </span>
                    <span className="font-display text-[1.15rem] leading-tight text-ink">Ver todos</span>
                    <span className="text-[11px] uppercase tracking-[0.16em] text-ink-mute">{total} produtos</span>
                  </Link>
                </li>
              ) : null}
            </ul>
          </Reveal>
        </section>
      ))}
    </>
  );
}
